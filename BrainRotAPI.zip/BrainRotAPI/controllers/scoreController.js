const admin = require('firebase-admin');
const db = admin.firestore();

exports.submitScore = async (req, res) => {
  const { gameName, username, score } = req.body; // 'username' is the currently logged-in user's username

  try {
    // Log the score being submitted
    console.log(`Submitting score: ${score} for user: ${username} in game: ${gameName}`);

    // Query the leaderboard to check if a document exists for the user and game
    const leaderboardQuery = await db.collection('Leaderboard')
      .where('Username', '==', username)
      .where('GameName', '==', gameName)
      .get();

    let leaderboardRef;

    // If no document exists, create a new one with a randomly generated ID
    if (leaderboardQuery.empty) {
      leaderboardRef = await db.collection('Leaderboard').add({
        GameName: gameName,
        Username: username,
        HighScore: score
      });

      // Initialize PrivateLeaderboard subcollection for this user
      await leaderboardRef.collection('PrivateLeaderboard').doc('init').set({});
      
      res.status(200).json({ message: 'Score submitted and new document created successfully!' });
    
    } else {
      // Document exists, so update the high score if necessary
      const leaderboardDoc = leaderboardQuery.docs[0];
      leaderboardRef = leaderboardDoc.ref;

      const existingHighScore = leaderboardDoc.data().HighScore || 0; // Default to 0 if undefined

      console.log(`Current high score for ${username} in ${gameName}: ${existingHighScore}, New score: ${score}`);

      if (score > existingHighScore) {
        // Update the leaderboard high score
        await leaderboardRef.update({ HighScore: score });
        console.log('High score updated successfully!');

        // Update other users' private leaderboards where this user is added
        const privateLeaderboardQuery = await db.collection('Leaderboard')
          .where('GameName', '==', gameName)
          .where('Username', '!=', username)  // Exclude the current user
          .get();

        for (const doc of privateLeaderboardQuery.docs) {
          const privateLeaderboardRef = doc.ref.collection('PrivateLeaderboard').doc(username);
          const privateDoc = await privateLeaderboardRef.get();

          // Update the user's score in other users' private leaderboards if necessary
          if (privateDoc.exists && privateDoc.data().HighScore < score) {
            await privateLeaderboardRef.update({
              HighScore: score
            });
            console.log(`Updated private leaderboard for ${username} in ${doc.data().Username}'s leaderboard.`);
          }
        }

        res.status(200).json({ message: 'Score updated successfully!' });
      } else {
        console.log('Score not high enough to update.');
        res.status(200).json({ message: 'Score not high enough to update.' });
      }
    }

  } catch (error) {
    console.error('Error submitting score:', error);
    res.status(500).send('Error submitting score: ' + error.message);
  }
};
