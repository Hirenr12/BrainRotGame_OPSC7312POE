const admin = require('firebase-admin');
const db = admin.firestore();

// Fetch global leaderboard for a specific game
exports.getGlobalLeaderboard = async (req, res) => {
  const gameName = req.params.gameName;

  try {
    const leaderboardRef = db.collection('Leaderboard');
    const snapshot = await leaderboardRef
      .where('GameName', '==', gameName)
      .orderBy('HighScore', 'desc')
      .get();

    if (snapshot.empty) {
      res.status(404).send(`No leaderboard found for the game: ${gameName}.`);
      return;
    }

    const leaderboard = [];
    snapshot.forEach(doc => {
      leaderboard.push(doc.data());
    });

    res.status(200).json(leaderboard);
  } catch (error) {
    res.status(500).send('Error fetching leaderboard: ' + error.message);
  }
};



// Fetch private leaderboard for a specific game and username
exports.getPrivateLeaderboard = async (req, res) => {
  const { gameName, username } = req.params;

  try {
    // Find the specific leaderboard document for the user
    const leaderboardRef = db.collection('Leaderboard');
    const querySnapshot = await leaderboardRef
      .where('GameName', '==', gameName)
      .where('Username', '==', username)
      .get();

    if (querySnapshot.empty) {
      res.status(404).send('No private leaderboard found for this user.');
      return;
    }

    // each user has only one document in the leaderboard collection for each game
    const userDoc = querySnapshot.docs[0];
    const privateLeaderboardRef = userDoc.ref.collection('PrivateLeaderboard');
    const privateSnapshot = await privateLeaderboardRef
      .orderBy('HighScore', 'desc')
      .get();

    if (privateSnapshot.empty) {
      res.status(404).send('No entries found in the private leaderboard.');
      return;
    }

    const privateLeaderboard = [];
    privateSnapshot.forEach((doc) => {
      privateLeaderboard.push(doc.data());
    });

    res.status(200).json(privateLeaderboard);
  } catch (error) {
    res.status(500).send('Error fetching private leaderboard: ' + error.message);
  }
};





// Fetch list of all unique games
exports.getAllGames = async (req, res) => {
  try {
      const leaderboardRef = db.collection('Leaderboard');
      const snapshot = await leaderboardRef.get();

      if (snapshot.empty) {
          res.status(404).send('No games found.');
          return;
      }

      const games = new Set();
      snapshot.forEach(doc => {
          games.add(doc.data().GameName);
      });

      res.status(200).json([...games]); // Convert set to array
  } catch (error) {
      res.status(500).send('Error fetching games: ' + error.message);
  }
};







// Fetch list of all unique private games for a specific user
exports.getAllPrivateGames = async (req, res) => {
  const currentUser = req.params.currentUser; // Consistent parameter name

  try {
    // Reference to the Leaderboard collection
    const leaderboardRef = db.collection('Leaderboard');
    
    // Query to get all leaderboard documents for the user
    const snapshot = await leaderboardRef
      .where('Username', '==', currentUser)
      .get();

    if (snapshot.empty) {
      res.status(404).send('No private games found for this user.');
      return;
    }

    const privateGames = new Set();
    const promises = [];

    // Loop through each document in the Leaderboard collection for the user
    snapshot.forEach(doc => {
      const privateLeaderboardRef = doc.ref.collection('PrivateLeaderboard');
      // Create a promise to handle private leaderboard fetching
      promises.push(privateLeaderboardRef.get().then(privateSnapshot => {
        if (!privateSnapshot.empty) {
          privateGames.add(doc.data().GameName); // Add game name to the set
        }
      }));
    });

    // Wait for all promises to resolve
    await Promise.all(promises);

    // Send the unique private games as a response
    res.status(200).json([...privateGames]); // Convert Set to Array
  } catch (error) {
    res.status(500).send('Error fetching private games: ' + error.message);
  }
};






// Route to add a user to another user's PrivateLeaderboard sub-collection
exports.addToPrivateLeaderboard = async (req, res) => {
  const { currentUser, selectedUser, gameName } = req.body;

  try {
    // Find the current user's document in the Leaderboard collection for the specific game
    const leaderboardRef = db.collection('Leaderboard');
    const currentUserSnapshot = await leaderboardRef
      .where('Username', '==', currentUser)
      .where('GameName', '==', gameName)
      .get();

    if (currentUserSnapshot.empty) {
      return res.status(404).send('No leaderboard document found for the current user.');
    }

    const currentUserDoc = currentUserSnapshot.docs[0];
    const privateLeaderboardRef = currentUserDoc.ref.collection('PrivateLeaderboard');

    // Check if the selected user exists in the Leaderboard collection for the same game
    const selectedUserSnapshot = await leaderboardRef
      .where('Username', '==', selectedUser)
      .where('GameName', '==', gameName)
      .get();

    if (selectedUserSnapshot.empty) {
      return res.status(404).send('No leaderboard document found for the selected user.');
    }

    // Get the selected user's document and data
    const selectedUserDoc = selectedUserSnapshot.docs[0];
    const selectedUserData = selectedUserDoc.data();

    // Add the selected user's data to the PrivateLeaderboard sub-collection with the same document ID
    await privateLeaderboardRef.doc(selectedUserDoc.id).set({
      Username: selectedUserData.Username,
      GameName: selectedUserData.GameName,
      HighScore: selectedUserData.HighScore
    });

    res.status(200).send('User successfully added to Private Leaderboard.');
  } catch (error) {
    res.status(500).send('Error adding user to Private Leaderboard: ' + error.message);
  }
};

