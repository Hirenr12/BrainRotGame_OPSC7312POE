const express = require('express');
const router = express.Router();
const { getGlobalLeaderboard, getPrivateLeaderboard, getAllGames, getAllPrivateGames, addToPrivateLeaderboard } = require('../controllers/leaderboardController');

// Route to fetch all games
router.get('/global/allGames', getAllGames);

// Route to fetch all games 
router.get('/private/privateGames/:currentUser', getAllPrivateGames);

// Route for fetching global leaderboard for a specific game
router.get('/global/:gameName', getGlobalLeaderboard);

// Route to add a user to another user's private leaderboard
router.post('/private/:gameName/:currentUser/:selectedUser', addToPrivateLeaderboard);

// Route for private leaderboard to accept gameName and username
router.get('/private/:gameName/:username', getPrivateLeaderboard);

module.exports = router;
